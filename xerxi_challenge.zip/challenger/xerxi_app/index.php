<?php
session_start(); // Start the session
$msg = ""; // Initialize message variable

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Perform any necessary validation or sanitization here

    // Connect to your database (replace placeholders with your actual database credentials)
    $servername = "mysql_db"; // Update to match the service name
    $username_db = "root";
    $password_db = "quack"; // Consider setting a secure password here
    $dbname = "xerxi";
    
    // Create connection
    $conn = new mysqli($servername, $username_db, $password_db, $dbname);
    

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare SQL statement to retrieve user data
    $sql = "SELECT * FROM users_app WHERE username = ?";

    // Prepare and bind parameters to prevent SQL injection
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);

    // Execute query
    $stmt->execute();

    // Get result
    $result = $stmt->get_result();
    $password = md5($password);
    // Check if user exists
    if ($result->num_rows > 0) {
        // Fetch row
        $row = $result->fetch_assoc();

        // Verify password (you may need to adjust this depending on your password hashing method)
        if ($password == $row["password"]) {
            // Password is correct, perform login logic here
            // For example, set session variables or redirect user to dashboard
            $msg = "Login successful! Redirecting...";
            $_SESSION["logged"] = $_POST["username"];
            $_SESSION["pw"] = $_POST["password"];
            // Redirect after a short delay
            if ($_POST["username"] = "PVT") {
                header("refresh:2; url=dashboard/dashboard.php"); // Change "dashboard.php" to the desired destination
            } else if ($_POST["username"] = "GEN") {
                header("refresh:2; url=dashboard/adminDashboard.php");
            } else if ($_POST["username"] = "SRG") {
                header("refresh:2; url=dashboard/superadminDashboard.php");
            }
        } else {
            // Password is incorrect
            $msg = "Incorrect password!";
        }
    } else {
        // User does not exist
        $msg = "User not found!";
    }

    // Close connection
    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>XER.XI // Login</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }

        #red-divider, #login-divider {
            width: 50%;
            height: 100vh;
            padding: 0;
            margin: 0;
        }

        #red-divider {
            background-color: #ff3f34;
            float: left;
        }

        #login-divider {
            width: 50%;
            height: 100vh;
            background-color: #333;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            position: relative;
        }

        #login-form {
            width: 400px;
            border-radius: 8px;
        }

        h2 {
            margin-bottom: 30px;
            font-size: 40px;
            text-align: center;
            color: #ff3f34;
        }

        .input-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-size: 22px;
            color: #ff3f34;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            font-size: 24px;
            border: none;
            border-radius: 4px;
            background-color: #777;
            color: #ff3f34;
        }
        input[type="text"]:focus,
        input[type="password"]:focus {
            outline: none; /* Remove default focus outline */
            background-color: #262626; /* Change background color when focused */
        }
        input[type="text"]:active,
        input[type="password"]:active {
            background-color: #262626; /* Change background color when active */
        }
        button {
            width: 420px;
            height: 70px;
            padding: 10px;
            border: none;
            border-radius: 4px;
            background-color: #ff3f34;
            color: #333;
            font-size: 24px;
            cursor: pointer;
            position: relative;
            overflow: hidden;
        }

        button::before,
        button::after {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;

            background-color: #333;

            transition: left 0.3s ease;
        }

        button::after {
            color: #ff3f34;
            left: 100%;
        }

        button:hover::before {
            left: 0;
        }

        button:hover::after {
            left: 0;
        }


        #logo-container {
            width: 100%;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        #logo {
            width: 80vh;
            height: auto;
        }

        #footer {
            width: 100%;
            height: 50px;
            background-color: #444;
            color: #fff;
            text-align: center;
            line-height: 50px;
            position: absolute;
            bottom: 0;
        }

        a {
            color: #ff3f34;
            text-align: center;
            padding: 10px;
        }

    </style>
</head>
<body>
<span class="loading-bar"></span>
<div id="red-divider">
    <div id="logo-container">
        <img id="logo" src="images/XER.XI.png" alt="Logo">
    </div>
</div>

<div id="login-divider">
    <span class="loading-bar"></span>
    <form id="login-form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <h2>Login</h2>

        <div class="input-group">
            <label for="username">Username</label>
            <input type="text" id="username" name="username" required>
        </div>
        <div class="input-group">
            <label for="password">Password</label>
            <input type="password" id="password" name="password" required>
        </div>
        <button type="submit">Login</button>
    </form>
    <a><?php echo $msg;?></a>
    <div id="footer">
        &copy; 2027 XER.XI. All rights reserved.
    </div>
</div>
</body>
</html>
