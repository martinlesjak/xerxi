<?php
session_start();
$msg = "";

// Check if the user is logged in. Replace this with your authentication logic.
if (!isset($_SESSION['logged'])) {
    header("Location: ../index.php"); // Redirect to the login page if not logged in
    exit();
}
if ($_SESSION['logged'] != "PVT") {
    header("Location: ../index.php"); // Redirect to the login page if not logged in
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $servername = "mysql_db";
    $username_db = "root";
    $password_db = "quack";
    $dbname = "xerxi";

    // Create connection
    $conn = new mysqli($servername, $username_db, $password_db, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $usr = $_POST["username"];
    $passwordOld = $_POST["currentPassword"];
    $passwordNew = $_POST["newPassword"];
    $passwordRet = $_POST["confirmPassword"];
    $hashedPassword = md5($passwordNew);
    if ($usr != "SRG") {
    if ($passwordNew == $passwordRet) {
        // Retrieve the old password from the session or the database
        $oldPass = $_SESSION["pw"]; // You need to set $_SESSION["pw"] somewhere in your code

        // Check if the old password matches
        if ($oldPass == $passwordOld) {
            // Concatenate user inputs directly into SQL query (extremely vulnerable to SQL injection)
            $sql = "UPDATE users_app SET password = '" . $hashedPassword . "' WHERE username = '" . $usr . "'";
            if ($conn->query($sql) === TRUE) {
                $msg = "Password updated successfully. Redirecting...";
                header("refresh:2;url=../index.php");

            } else {
                $msg = "Error updating password: " . $conn->error;
            }
        } else {
            $msg = "Old password is incorrect.";
        }
    } else {
        $msg = "Passwords do not match.";
    }
    } else {
        $msg = "Access denied.";
    }
}

$username = $_SESSION['logged'];
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-color: #333;
            color: #fff;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            width: 400px;
            padding: 20px;
            background-color: #262626;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
        }

        h2 {
            color: #ff0d0d;
            text-align: center;
            margin-bottom: 20px;
        }

        label {
            color: #ff3f34;
            display: block;
            margin-bottom: 10px; /* Add margin bottom for spacing */
        }

        input[type="password"], input[type="text"] {
            width: 80%;
            padding: 15px; /* Increase padding for more spacious feel */
            margin-bottom: 20px;
            border: none;
            border-radius: 5px;
            background-color: #777;
            color: #fff;
        }

        button[type="submit"] {
            padding: 15px 20px; /* Increase padding for button */
            border: none;
            border-radius: 5px;
            background-color: #b20b0b;
            color: #fff;
            cursor: pointer;
            transition: background-color 0.3s;
            display: block;
            margin: 0 auto;
        }

        button[type="submit"]:hover {
            margin: 20px;
            background-color: #ff3f34;
        }
        a {
            color: #ff6a00;
            text-align: center;
        }


    </style>
</head>
<body>
<div class="container">
    <h2>Change Password</h2>
    <a><?php echo $msg;?></a>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <div class="form-group">
            <label for="username">Username</label>
            <input type="text" id="username" name="username" value="<?php echo $username;?>">
        </div>
        <div class="form-group">
            <label for="currentPassword">Current Password</label>
            <input type="password" id="currentPassword" name="currentPassword" required>
        </div>
        <div class="form-group">
            <label for="newPassword">New Password</label>
            <input type="password" id="newPassword" name="newPassword" required>
        </div>
        <div class="form-group">
            <label for="confirmPassword">Confirm New Password</label>
            <input type="password" id="confirmPassword" name="confirmPassword" required>
        </div>

        <button type="submit">Change Password</button>
    </form>

</div>
</body>
</html>
