<?php
session_start();
session_unset();
session_destroy();
header("Refresh: 2; url=../index.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logout | Dojo Manager</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #262626;
            font-family: Arial, sans-serif;
        }

        .container {
            background-color: #ff0000;
            padding: 20px;
            color: white;
            border-radius: 5px;
            text-align: center;
        }

    </style>
</head>
<body>
<div class="container">
    <h4>Logging out...</h4>
</div>
</body>
</html>

