<?php
session_start(); // Start the session

$msg = ""; // Initialize message variable

// Check if the "logged" key is set in the session

if (!isset($_SESSION["logged"])) {
    header("Location: ../index.php");

}
if ($_SESSION["logged"] != "SRG") {
    header("Location: ../index.php");
}
if (isset($_SESSION["logged"])) {
    $user = $_SESSION["logged"];

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $user."'s " ?>Dashboard</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-color: #333;
            color: #fff;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            width: 100%;
            display: flex;
            flex-direction: column;
            height: 100vh; /* Ensure the container takes full height of the viewport */
        }

        nav {
            background-color: #ff3f34;
            padding: 10px 0;
            text-align: center;
            margin: 0;
            width: 100%;
            flex: 0 0 auto; /* Allow navbar to grow and shrink */
        }

        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
        }

        nav ul li {
            display: inline;
            margin-right: 20px;
        }

        nav ul li a {
            color: #fff;
            text-decoration: none;
            font-size: 18px;
        }

        .navbar a {
            color: #b20b0b;
            text-decoration: none;
            margin: 0 20px;
            font-size: 28px;
            position: relative; /* Add position relative */
        }

        .navbar a::before {
            content: "";
            position: absolute;
            bottom: -5px; /* Adjust as needed */
            left: 0;
            width: 0;
            height: 2px; /* Adjust line height */
            background-color: #ff0d0d; /* Line color */
            transition: width 0.3s ease; /* Transition for line width */
        }

        .navbar a:hover::before {
            width: 100%; /* Grow line to the left */
        }


        .navbar a::before {
            content: "";
            position: absolute;
            bottom: -5px; /* Adjust as needed */
            left: 0;
            width: 0;
            height: 2px; /* Adjust line height */
            background-color: #101010; /* Line color */
            transition: width 0.3s ease; /* Transition for line width */
        }

        .navbar a:hover::before {
            width: 100%; /* Grow line to the left */
        }

        .navbar a:hover {
            color: #101010; /* Line color */
            text-decoration: none;
            margin: 0 20px;
            transition-duration: 0.3s;
        }

        main {
            text-align: center;
            display: flex;
            flex: 1; /* Allow main content to take remaining space */
        }

        .divider {
            width: 33%;
            padding: 20px;
            box-sizing: border-box; /* Include padding in the width */
        }

        textarea {
            width: 100%;
            height: 80vh;
            padding: 10px;
            font-size: 24px;
            border: none;
            background-color: #777;
            color: #fff;
            resize: vertical; /* Allow vertical resizing */
            min-height: 200px; /* Set a minimum height */
        }

        footer {
            background-color: #666;
            padding: 10px 0;
            text-align: center;
            margin: 0;
            width: 100%;
            flex: 0 0 auto; /* Allow footer to grow and shrink */
        }
        /* Modal styles */
        .modal {
            display: none; /* Hidden by default */
            position: fixed; /* Stay in place */
            z-index: 1; /* Sit on top */
            left: 0;
            top: 0;
            width: 100%; /* Full width */
            height: 100%; /* Full height */
            overflow: auto; /* Enable scroll if needed */
            background-color: rgb(0,0,0); /* Fallback color */
            background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
        }

        .modal-content {
            background-color: #262626;
            margin: 15% auto;
            padding: 20px;
            border: 1px solid #101010;
            width: 80%;
            color: #ff0d0d;
        }

        .close {
            color: #770707;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: #ff0d0d;
            text-decoration: none;
            cursor: pointer;
        }
        /* Blocks container styles */
        .blocks-container {
            display: flex;
            flex-wrap: wrap;
        }

        /* Block styles */
        .block {
            width: 200px;
            height: 200px;
            background-color: #101010;
            margin: 10px;
        }
        .block img {
            width: 100%;
            height: 100%;
        }

        #taskList li, #missionList li, #logList li {
            list-style: none;
            text-align: left;
            background: #181818;
            padding: 20px;
            font-size: 20px;
            color: #ff0d0d;
            border-radius: 5px;
            margin: 10px;
        }
        #newTaskInput, #newSearchUp {
            text-align: left;
            background: rgba(182, 81, 81, 0.1);
            padding: 20px;
            font-size: 20px;
            color: #ff0d0d;
            border-radius: 5px;
            margin: 10px;
        }
        #taskInput, #searchButton, #addnewmission {
            border-style: none;
            background: #262626;
            padding: 20px;
            font-size: 20px;
            color: #ff0d0d;
            border-radius: 5px;
            margin: 10px;
        }

        .newmission, .newmissiondesc {
            border-style: solid;
            background: #262626;
            padding: 20px;
            font-size: 20px;
            color: #ff0d0d;
            border-radius: 5px;
            margin: 10px;
        }

        .divider2 {
            width: 100%;
            height: 80vh;
            padding: 10px;
            font-size: 24px;
            border: none;
            background-color: #333333;
            color: #fff;
            resize: vertical; /* Allow vertical resizing */
            min-height: 200px; /* Set a minimum height */
        }
        @keyframes blink {
            0% { opacity: 1; }
            50% { opacity: 0; }
            100% { opacity: 1; }
        }

        /* Apply blinking animation to elements with class "blinking" */

        a {
            color: red; /* Make text red */
            text-align: left; /* Align text to the left */
            font-size: 30px;
            padding: 20px;
        }
        .blinking {
            animation: blink 1s infinite;

        }
        hr {

        }
    </style>
</head>
<body>

<nav class="navbar">
    <ul>
        <li><a id="profileLink" href="#">Teams</a></li>
        <li><a id="missionLink" href="#">Missions</a></li>
        <li><a id="logLink">Logs</a></li>
        <li><a href="logout.php">Logout</a></li>
    </ul>
</nav>
<p><?php echo $msg;?></p>
<div id="profileModal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <h2>Teams</h2>
        <!-- Add your profile content here -->
        <p>Team 1 - Objective Initiators</p>
        <div class="blocks-container">
            <div class="block"><img src="../images/operators/op1.png"></div>
            <p><b>Sergeant Sgt. Black</b><br>Dark company.<br> Eight years in business.<br>CQB specialization.<br>Highly effective.</p>
            <div class="block"><img src="../images/operators/op2.png"></div>
            <p><b>Private Pvt. Dock</b><br>Dark company.<br> Five years in business.<br>Long range specialization.<br>Loyal mercenary.</p>
            <div class="block"><img src="../images/operators/op3.png"></div>
            <p><b>Private Pvt. Roy</b><br>Firefighter turned soldier.<br>Highly skilled in urban combat.<br>Specialized in close-quarters combat.<br>Quick reflexes.</p>
            <div class="block"><img src="../images/operators/user-256.png"></div>
            <p><b>Private Pvt. K</b><br>Mountain Divison 45.<br> Nine years in business.<br>Traps specialization.<br>Psychotic but effective.</p>
            <div class="block"><img src="../images/operators/user-256.png"></div>
            <p><b>Private Pvt. EWS</b><br>Division 124.<br> Three years in business.<br>Cybernetic warfare expert.<br>Fast and efficient.</p>
        </div>
        <p>Team 2 - Cleanup Squad</p>
            <div class="blocks-container">
            <div class="block"><img src="../images/operator2/opa.png"></div>
            <p><b>Private Pvt. Jon</b><br>Dark company.<br> Twenty years in business.<br>Cleanup specialization.<br>Ex-criminal.</p>
            <div class="block"><img src="../images/operator2/opb.png"></div>
            <p><b>Private Pvt. Knox</b><br>Dark company.<br> Seven years in business.<br>Explosives expert.<br>Ex-mafia.</p>
            <div class="block"><img src="../images/operator2/opc.png"></div>
            <p><b>Private Pvt. Zakhaev</b><br>Russian special ops.<br>Martial arts fighter.<br>Brutal in close range.<br>Self-initiative.</p>
            <div class="block"><img src="../images/operator2/opd.png"></div>
            <p><b>Private Pvt. Mor</b><br>Likes cats.</p>
        </div>
    </div>
</div>

<div id="missionModal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <h2>Missions</h2>
        <input type="text" id="newSearchUp" placeholder="Search...">
        <button id="searchButton">Go!</button>
        <br>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="get">
        <input type="text" class="newmission" name="newMission" placeholder="Name...">
        <input type="text" class="newmissiondesc" name="newDescription" placeholder="Description...">
        <input type="submit" id="addnewmission" name="addMission" value="Add">
    </form>

        <!-- Add more missions to the existing list -->
        <ul id="missionList">
            <li><h2>Mission 25 - Bangkok</h2><br><p>Provide security detail for a high-profile client during a diplomatic summit in the bustling streets of Bangkok. Navigate through the city's vibrant markets and bustling nightlife while ensuring the safety of your charge.</p></li>
            <li><h2>Mission 24 - Berlin</h2><br><p>Secure a valuable shipment of weapons and equipment as it makes its way through the urban landscape of Berlin. Keep a watchful eye on potential threats from rival mercenary groups seeking to intercept the cargo.</p></li>
            <li><h2>Mission 23 - Buenos Aires</h2><br><p>Escort a convoy of VIPs through the chaotic streets of Buenos Aires, shielding them from potential attacks by local criminal organizations. Utilize your tactical skills to navigate through the city's bustling traffic and crowded neighborhoods.</p></li>
            <li><h2>Mission 22 - Cairo</h2><br><p>Retrieve a stolen artifact from a heavily guarded museum in the heart of Cairo. Infiltrate the museum under the cover of darkness, outmaneuvering the security systems and avoiding detection by patrolling guards.</p></li>
            <li><h2>Mission 21 - Chicago</h2><br><p>Provide protection for a high-profile client attending a clandestine meeting with rival factions in the urban sprawl of Chicago. Keep a low profile while ensuring the safety of your client amidst the city's notorious underworld.</p></li>
            <li><h2>Mission 20 - Dubai</h2><br><p>Assist a wealthy client in reclaiming control of their luxury yacht seized by pirates off the coast of Dubai. Engage in high-speed maritime combat as you board the vessel and neutralize the hostile threat.</p></li>
            <li><h2>Mission 19 - Hong Kong</h2><br><p>Infiltrate a rival corporation's headquarters in the bustling metropolis of Hong Kong to extract sensitive data. Navigate through the corporate skyscrapers, bypassing security checkpoints and hacking into secure servers to retrieve the information.</p></li>
            <li><h2>Mission 18 - Istanbul</h2><br><p>Secure a lucrative arms deal between two rival factions in the ancient city of Istanbul. Negotiate with local arms dealers and ensure the safe exchange of weapons while fending off potential double-crosses from both sides.</p></li>
            <li><h2>Mission 17 - Johannesburg</h2><br><p>Protect a convoy of humanitarian aid supplies as they travel through the dangerous streets of Johannesburg. Navigate through the city's volatile neighborhoods, warding off attacks from armed militia groups and ensuring the safe delivery of the supplies.</p></li>
            <li><h2>Mission 16 - Kuala Lumpur</h2><br><p>Extract a high-value target from a heavily guarded compound in the heart of Kuala Lumpur. Infiltrate the facility under the cover of darkness, eliminating security personnel and extracting the target before reinforcements arrive.</p></li>
            <li><h2>Mission 15 - Lagos</h2><br><p>Retrieve stolen artwork from a notorious art thief hiding out in the sprawling slums of Lagos. Navigate through the maze-like streets, tracking down the thief's hideout and recovering the stolen treasures.</p></li>
            <li><h2>Mission 14 - Los Angeles</h2><br><p>Provide security detail for a celebrity client attending a high-profile event in the glamorous city of Los Angeles. Navigate through the throngs of paparazzi and overzealous fans while ensuring the safety of your VIP.</p></li>
            <li><h2>Mission 13 - Manila</h2><br><p>Assassinate a high-ranking government official orchestrating corruption schemes in the bustling capital of Manila. Infiltrate the government building, eliminating security forces and neutralizing the target without attracting unwanted attention.</p></li>
            <li><h2>Mission 12 - Moscow</h2><br><p>Retrieve a stolen prototype weapon from a rival mercenary group operating in the shadowy underworld of Moscow. Infiltrate the group's compound, engaging in intense firefights and recovering the weapon before it falls into the wrong hands.</p></li>
            <li><h2>Mission 11 - Mumbai</h2><br><p>Rescue a kidnapped businessman held captive by a notorious criminal syndicate in the chaotic streets of Mumbai. Infiltrate the syndicate's stronghold, neutralizing their forces and extracting the hostage before it's too late.</p></li>
            <li><h2>Mission 10 - New York City</h2><br><p>Eliminate a high-value target hiding out in the urban jungle of New York City. Navigate through the city's crowded streets and towering skyscrapers, tracking down the target and neutralizing their security detail.</p></li>
            <li><h2>Mission 9 - Rio de Janeiro</h2><br><p>Retrieve stolen intelligence documents from a rival espionage agency operating in the vibrant streets of Rio de Janeiro. Infiltrate the agency's headquarters, bypassing security measures and recovering the classified information.</p></li>
            <li><h2>Mission 8 - Seoul</h2><br><p>Assassinate a rogue scientist conducting illegal experiments in a hidden laboratory beneath the bustling city of Seoul. Infiltrate the laboratory, navigating through its maze-like corridors and eliminating the scientist before his creations pose a threat to global security.</p></li>
            <li><h2>Mission 7 - Sydney</h2><br><p>Secure a valuable shipment of technology components as it makes its way through the bustling port city of Sydney. Intercept rival mercenary groups seeking to hijack the shipment, engaging in high-speed maritime combat to ensure its safe delivery.</p></li>
            <li><h2>Mission 6 - Tehran</h2><br><p>Extract a defecting scientist from a top-secret research facility hidden deep beneath the streets of Tehran. Infiltrate the facility, neutralizing security forces and escorting the scientist to safety before their knowledge falls into the wrong hands.</p></li>
            <li><h2>Mission 5 - Tokyo</h2><br><p>Infiltrate a high-security research facility in the heart of Tokyo to steal advanced technology prototypes. Navigate through the facility's labyrinthine corridors, avoiding detection from security systems and retrieving the prototypes before they fall into the wrong hands.</p></li>
            <li><h2>Mission 4 - Buenos Aires</h2><br><p>Provide security detail for a high-profile political figure attending a diplomatic summit in Buenos Aires. Navigate through the city's bustling streets and ensure the safety of your client amidst the backdrop of political intrigue and potential threats.</p></li>
            <li><h2>Mission 3 - Cairo</h2><br><p>Extract a valuable artifact from a heavily guarded museum in the ancient city of Cairo. Infiltrate the museum under the cover of darkness, bypassing security measures and retrieving the artifact before the authorities are alerted to its theft.</p></li>
            <li><h2>Mission 2 - Nairobi</h2><br><p>Track down and eliminate a notorious warlord operating in the lawless streets of Nairobi. Navigate through the city's sprawling slums, gathering intel on the warlord's whereabouts and neutralizing his forces before he can cause further harm.</p></li>
            <li><h2>Mission 1 - Marrakesh</h2><br><p>Escort a high-value target through the bustling markets of Marrakesh, protecting them from rival mercenary groups seeking to capture or eliminate them. Navigate through the narrow alleyways and crowded streets, ensuring the safety of your client amidst the chaos of the city.</p></li>
        </ul>

    </div>
</div>

<div id="logModal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <h2>Logs</h2>
        <ul id="logList">

            <li><h2>Log 6</h2><p>adminDashboard & superadminDashboard - 23:12 - switched privileges. SRG is super admin.</p></li>
        <li><h2>Log 5</h2><p>index.php - 17:50 - parameters added.</p></li>
            <li><h2>Log 4</h2><p>index.php - 17:02 - parameters added.</p></li>
            <li><h2>Log 3</h2><p>settings.php - 11:19 - reworked styles css.</p></li>
            <li><h2>Log 2</h2><p>procc.htaccess - 12.13 - added security.</p></li>
            <li><h2>Log 1</h2><p>index.php - 10:00 - created.</p></li>
        </ul>
    </div>
</div>


<div class="container">
    <main>
        <div class="divider">
            <a class="blinking">Current Mission:</a>
            <textarea placeholder="Type here..." id="textArea" rows="5"></textarea>
        </div>
        <div class="divider">
            <div class="divider2">
                <input type="text" id="newTaskInput" placeholder="Add a new task">
                <button id="taskInput" onclick="addTask()">Add Task</button>
                <ul id="taskList">
                </ul>

            </div>

        </div>
        <div class="divider">
            <a>Personal notes:</a>
            <textarea placeholder="Type here..." id="textArea notes" rows="5"></textarea>
        </div>
    </main>
</div>
<footer>
    <p>XERXI WebApp v1.0</p>
</footer>
<script>
    document.getElementById("searchButton").addEventListener("click", function() {
        searchMissions();
    });

    function searchMissions() {
        // Get the search query
        var searchQuery = document.getElementById("newSearchUp").value.toLowerCase();

        // Get all mission elements
        var missions = document.getElementById("missionList").getElementsByTagName("li");

        // Loop through each mission
        for (var i = 0; i < missions.length; i++) {
            var missionTitle = missions[i].getElementsByTagName("h2")[0].innerText.toLowerCase();

            // Check if the mission title contains the search query
            if (missionTitle.includes(searchQuery)) {
                // If it does, display the mission
                missions[i].style.display = "";
            } else {
                // If it doesn't, hide the mission
                missions[i].style.display = "none";
            }
        }
    }



    // Get the modal
    var modal = document.getElementById("profileModal");

    // Get the <span> element that closes the modal
    var span = document.getElementsByClassName("close")[0];

    // When the user clicks on the profile link, open the modal
    document.getElementById("profileLink").onclick = function() {
        modal.style.display = "block";
    }
    // Get the modal
    var modal = document.getElementById("profileModal");



    // Get the <span> element that closes the modal
    var span = document.getElementsByClassName("close")[0];

    // Get the modal for missions
    var missionModal = document.getElementById("missionModal");

    // When the user clicks on the mission link, open the modal
    document.getElementById("missionLink").onclick = function() {
        missionModal.style.display = "block";
    }

    // Get the close button for the mission modal
    var missionClose = missionModal.getElementsByClassName("close")[0];

    // When the user clicks on <span> (x) in the mission modal, close the modal
    missionClose.onclick = function() {
        missionModal.style.display = "none";
    }

    // When the user clicks on <span> (x), close the modal
    span.onclick = function() {
        modal.style.display = "none";
    }

    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }
    document.getElementById("textArea notes").value = "6y4Jb2Hb5tUioPq12dVb";
    document.getElementById("textArea").value = "Mission: Kazahstan\nMission plan: Execute rebel group.\nPay: 50.000$\nTime: 100 hours";
    function addTask() {
        // Get the input field value
        var newTask = document.getElementById("newTaskInput").value;

        // If the input field is empty, do nothing
        if (!newTask.trim()) {
            return;
        }

        // Create a new list item
        var listItem = document.createElement("li");

        // Create a new checkbox
        var checkbox = document.createElement("input");
        checkbox.type = "checkbox";

        // Create a new label
        var label = document.createElement("label");
        label.textContent = newTask;

        // Append the checkbox and label to the list item
        listItem.appendChild(checkbox);
        listItem.appendChild(label);

        // Append the new list item to the task list
        document.getElementById("taskList").appendChild(listItem);

        // Clear the input field
        document.getElementById("newTaskInput").value = "";
    }
    // JavaScript code for the new logmodal
    // Get the modal
    var logModal = document.getElementById("logModal");

    // Get the close button for the logmodal
    var logClose = logModal.getElementsByClassName("close")[0];

    // When the user clicks on <span> (x) in the logmodal, close the modal
    logClose.onclick = function() {
        logModal.style.display = "none";
    }

    // When the user clicks on the login link, open the logmodal
    document.getElementById("logLink").onclick = function() {
        logModal.style.display = "block";
    }

</script>
</body>
</html>
