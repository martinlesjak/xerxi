<?php
session_start(); // Start the session

$msg = ""; // Initialize message variable

// Check if the "logged" key is set in the session
if (isset($_SESSION["logged"])) {
    $user = $_SESSION["logged"];
    if ($user == "GEN") {
        header("Location: adminDashboard.php");

    } else if ($user == "SRG") {
        header("Location: superadminDashboard.php");

    }
} else {
    // The user is not logged in, display an error message or redirect to the login page
    $user = "You are not logged in!";
    header("Location: ../index.php");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $user."'s " ?>Dashboard</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-color: #333;
            color: #fff;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            width: 100%;
            display: flex;
            flex-direction: column;
            height: 100vh; /* Ensure the container takes full height of the viewport */
        }

        nav {
            background-color: #ff3f34;
            padding: 10px 0;
            text-align: center;
            margin: 0;
            width: 100%;
            flex: 0 0 auto; /* Allow navbar to grow and shrink */
        }

        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
        }

        nav ul li {
            display: inline;
            margin-right: 20px;
        }

        nav ul li a {
            color: #fff;
            text-decoration: none;
            font-size: 18px;
        }

        .navbar a {
            color: #b20b0b;
            text-decoration: none;
            margin: 0 20px;
            font-size: 28px;
            position: relative; /* Add position relative */
        }

        .navbar a::before {
            content: "";
            position: absolute;
            bottom: -5px; /* Adjust as needed */
            left: 0;
            width: 0;
            height: 2px; /* Adjust line height */
            background-color: #ff0d0d; /* Line color */
            transition: width 0.3s ease; /* Transition for line width */
        }

        .navbar a:hover::before {
            width: 100%; /* Grow line to the left */
        }


        .navbar a::before {
            content: "";
            position: absolute;
            bottom: -5px; /* Adjust as needed */
            left: 0;
            width: 0;
            height: 2px; /* Adjust line height */
            background-color: #101010; /* Line color */
            transition: width 0.3s ease; /* Transition for line width */
        }

        .navbar a:hover::before {
            width: 100%; /* Grow line to the left */
        }

        .navbar a:hover {
            color: #101010; /* Line color */
            text-decoration: none;
            margin: 0 20px;
            transition-duration: 0.3s;
        }

        main {
            text-align: center;
            display: flex;
            flex: 1; /* Allow main content to take remaining space */
        }

        .divider {
            width: 50%;
            padding: 20px;
            box-sizing: border-box; /* Include padding in the width */
        }

        textarea {
            width: 100%;
            height: 80vh;
            padding: 10px;
            font-size: 24px;
            border: none;
            background-color: #777;
            color: #fff;
            resize: vertical; /* Allow vertical resizing */
            min-height: 200px; /* Set a minimum height */
        }

        footer {
            background-color: #666;
            padding: 10px 0;
            text-align: center;
            margin: 0;
            width: 100%;
            flex: 0 0 auto; /* Allow footer to grow and shrink */
        }
        /* Modal styles */
        .modal {
            display: none; /* Hidden by default */
            position: fixed; /* Stay in place */
            z-index: 1; /* Sit on top */
            left: 0;
            top: 0;
            width: 100%; /* Full width */
            height: 100%; /* Full height */
            overflow: auto; /* Enable scroll if needed */
            background-color: rgb(0,0,0); /* Fallback color */
            background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
        }

        .modal-content {
            background-color: #262626;
            margin: 15% auto;
            padding: 20px;
            border: 1px solid #101010;
            width: 80%;
            color: #ff0d0d;
        }

        .close {
            color: #770707;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: #ff0d0d;
            text-decoration: none;
            cursor: pointer;
        }
        /* Blocks container styles */
        .blocks-container {
            display: flex;
            flex-wrap: wrap;
        }

        /* Block styles */
        .block {
            width: 200px;
            height: 200px;
            background-color: #101010;
            margin: 10px;
        }
        .block img {
            width: 100%;
            height: 100%;
        }

        #taskList li {
            list-style: none;
            text-align: left;
            background: #262626;
            padding: 20px;
            font-size: 20px;
            color: #ff0d0d;
            border-radius: 5px;
            margin: 10px;
        }
        #newTaskInput {
            text-align: left;
            background: #262626;
            padding: 20px;
            font-size: 20px;
            color: #ff0d0d;
            border-radius: 5px;
            margin: 10px;
        }
        #taskInput {
            border-style: none;
            background: #262626;
            padding: 20px;
            font-size: 20px;
            color: #ff0d0d;
            border-radius: 5px;
            margin: 10px;
        }
        .divider2 {
            width: 100%;
            height: 80vh;
            padding: 10px;
            font-size: 24px;
            border: none;
            background-color: #333333;
            color: #fff;
            resize: vertical; /* Allow vertical resizing */
            min-height: 200px; /* Set a minimum height */
        }
        @keyframes blink {
            0% { opacity: 1; }
            50% { opacity: 0; }
            100% { opacity: 1; }
        }

        /* Apply blinking animation to elements with class "blinking" */
        .blinking {
            animation: blink 1s infinite;
            color: red; /* Make text red */
            text-align: left; /* Align text to the left */font-size: 30px;
        padding: 20px;
    </style>
</head>
<body>

    <nav class="navbar">
        <ul>
            <li><a id="profileLink" href="#">Division</a></li>
            <li><a href="settings.php">Settings</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </nav>
    <div id="profileModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2>Profile</h2>
            <!-- Add your profile content here -->
            <div class="blocks-container">
                <div class="block"><img src="../images/operators/op1.png"></div>
                <p><b>Sergeant Sgt. Black</b><br>Dark company.<br> Eight years in business.<br>CQB specialization.<br>Highly effective.</p>
                <div class="block"><img src="../images/operators/op2.png"></div>
                <p><b>Private Pvt. Dock</b><br>Dark company.<br> Five years in business.<br>Long range specialization.<br>Loyal mercenary.</p>
                <div class="block"><img src="../images/operators/op3.png"></div>
                <p><b>Private Pvt. Roy</b><br>Firefighter turned soldier.<br>Highly skilled in urban combat.<br>Specialized in close-quarters combat.<br>Quick reflexes.</p>
                <div class="block"><img src="../images/operators/user-256.png"></div>
                <p><b>Private Pvt. K</b><br>Mountain Divison 45.<br> Nine years in business.<br>Traps specialization.<br>Psychotic but effective.</p>
                <div class="block"><img src="../images/operators/user-256.png"></div>
                <p><b>Private Pvt. EWS</b><br>Division 124.<br> Three years in business.<br>Cybernetic warfare expert.<br>Fast and efficient.</p>
            </div>
        </div>
    </div>

    <div class="container">
    <main>
        <div class="divider">
            <a class="blinking">Current Mission:</a>
            <textarea placeholder="Type here..." id="textArea" rows="5"></textarea>
        </div>
        <div class="divider">
            <div class="divider2">
                <input type="text" id="newTaskInput" placeholder="Add a new task">
                <button id="taskInput" onclick="addTask()">Add Task</button>
                <ul id="taskList">
                </ul>

            </div>

        </div>
    </main>
    </div>
    <footer>
        <p>XERXI WebApp v1.0</p>
    </footer>
<script>
    // Get the modal
    var modal = document.getElementById("profileModal");

    // Get the <span> element that closes the modal
    var span = document.getElementsByClassName("close")[0];

    // When the user clicks on the profile link, open the modal
    document.getElementById("profileLink").onclick = function() {
        modal.style.display = "block";
    }

    // When the user clicks on <span> (x), close the modal
    span.onclick = function() {
        modal.style.display = "none";
    }

    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }
    document.getElementById("textArea").value = "Mission: Kazahstan\nMission plan: Execute rebel group.\nPay: 50.000$\nTime: 100 hours";
    function addTask() {
        // Get the input field value
        var newTask = document.getElementById("newTaskInput").value;

        // If the input field is empty, do nothing
        if (!newTask.trim()) {
            return;
        }

        // Create a new list item
        var listItem = document.createElement("li");

        // Create a new checkbox
        var checkbox = document.createElement("input");
        checkbox.type = "checkbox";

        // Create a new label
        var label = document.createElement("label");
        label.textContent = newTask;

        // Append the checkbox and label to the list item
        listItem.appendChild(checkbox);
        listItem.appendChild(label);

        // Append the new list item to the task list
        document.getElementById("taskList").appendChild(listItem);

        // Clear the input field
        document.getElementById("newTaskInput").value = "";
    }
</script>
</body>
</html>
