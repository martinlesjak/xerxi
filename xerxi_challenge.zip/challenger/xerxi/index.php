<?php
session_start();

$validUsername = 'guest';
$validPassword = 'password';

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get username and password from form submission
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Create a database connection (replace with your database connection code)
    $pdo = new PDO("mysql:host=mysql_db;dbname=xerxi", "root", "quack");

    // Prepare a SQL statement with placeholders
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = :username");

    // Bind parameters to the placeholders
    $stmt->bindParam(':username', $username);

    // Execute the statement
    $stmt->execute();

    // Fetch the user record
    $user = $stmt->fetch();

    // Verify if the user exists and the password is correct
    if ($user && password_verify($password, $user['password'])) {
        // Set session variables to indicate user is logged in
        $_SESSION['username'] = $username;
        $_SESSION['loggedIn'] = true;

        if ($username == 'root') {
            header('Location: wip/dashboard.php');
        } else {
        header('Location: mainsite/main.php');
        }
        exit;
    } else {
        // Display error message if login credentials are invalid
        $errorMsg = "Invalid username or password. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        /* Add your CSS styles here */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #262626;
            color: #fff;
            text-align: center;
        }
        .container {
            max-width: 400px;
            margin: 100px auto;
            padding: 20px;
            background-color: #333333;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
        }
        h2 {
            margin-bottom: 20px;
            color: #c00c0c; /* Gold color */
        }
        .login-link {
            display: block;
            margin-bottom: 20px;
            color: #c00c0c;
            text-decoration: none;
        }
        .login-link:hover {
            text-decoration: underline;
        }
        .error-message {
            color: #ff6347; /* Tomato color */
            margin-bottom: 10px;
        }
        input[type="text"],
        input[type="password"],
        button {
            width: 80%;
            padding: 10px;
            margin-bottom: 15px;
            border: none;
            border-radius: 5px;
            background-color: #444444;
            color: #fff;
            font-size: 16px;
        }
        button {
            background-color: #c00c0c;
            cursor: pointer;
            transition: background-color 0.3s, color 0.3s; /* Added color transition */
            position: relative; /* Added for absolute positioning of pseudo-element */
        }

        button::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 0;
            height: 2px;
            background-color: #ff4400;
            transition: width 0.3s; /* Added transition for width */
        }

        button:hover::after {
            width: 100%; /* Fills the width when hovered */
        }

        .logo {
            margin-bottom: 10px;
            margin-top: 10px;
            height: 200px;
            width: auto;
        }
        .footer {
            margin-top: 20px;
            color: #999999;
            font-size: 14px;
        }

        a::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 0;
            height: 20px;
            background-color: #ff0d0d;
            transition: width 0.3s; /* Added transition for width */
        }

        a:hover::after {
            width: 100%; /* Fills the width when hovered */
        }
    </style>
</head>
<body>
<div class="container">
    <img src="images/xerxi.png" alt="XER.XI Logo" class="logo" width="100">
    <h2>Login</h2>
    <?php if (isset($errorMsg)) : ?>
        <p class="error-message"><?= $errorMsg ?></p>
    <?php endif; ?>
    <p>Click 'Guest Login' if visiting.</p>
    <a href="mainsite/main.php" class="login-link">Guest Login</a>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
        <input type="text" name="username" placeholder="Username" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit">Login</button>
    </form>
    <div class="footer">
        &copy; 2024 XER.XI. All rights reserved.
    </div>
</div>
</body>
</html>
