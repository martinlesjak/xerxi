<?php

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Terminal Emulator</title>
    <style>
        body {
            background-color: #000;
            color: #25e825; /* Changed text color to green */
            font-family: monospace;
            padding: 20px;
            position: relative; /* Added position relative */
        }
        .terminal {
            height: 300px;
            overflow-y: auto;
            border: 2px solid #25e825;
            padding: 10px;
        }
        .flashing-cube {
            position: absolute;
            width: 20px;
            height: 20px;
            top: 0;
            background-color: #25e825;
            animation: blink 1s infinite; /* Added blinking animation */
        }

        .flashing {
            background-color: #25e825;
            width: 0px;
            animation: blink 1s infinite; /* Added blinking animation */
        }
        .terminal-content {
            position: relative;
            z-index: 1; /* Ensure terminal content appears above the cube */
        }
        .character {
            color: #25e825;
            font-size: 20px;
            animation: spin 1s linear infinite; /* Added spinning animation */
            position: absolute;
            bottom: 0;
        }
        @keyframes spin {
            0% {
                transform: rotate(0deg);
            }
            100% {
                transform: rotate(360deg);
            }
        }
        @keyframes blink {
            0% { opacity: 1; }
            50% { opacity: 0; }
            100% { opacity: 1; }
        }
    </style>
</head>
<body>
<div class="flashing-cube"></div><p class="flashing">Loading...</p> <!-- Added flashing cube -->
<p>Message broadcasted by: ///////////// /////////</p>
<div class="terminal terminal-content" id="terminal">
    <p>&lt;root@root&gt;&nbsp</p>
</div> <!-- Added class to terminal content -->


<script>
    const terminal = document.getElementById('terminal');
    const text = `They're lying. I would assume you know this already, why else would you be here? Their lies are...horrible. Care about others? Ha! If they've known...
They know. I hacked them, got most of the information, but not enough. I trust you. Here's a log, proving me right and demolishing their so called "helping hand":
\nSCIP_decode_2026_11_1_08_23_12
"What to do with ... them?"
- VC FLD / SRG 8us9e
\nSCIP_decode_2026_11_1_08_23_15
"Execute them. No witnesses."
- VC MHQ / GEN ui2o3
\nI hear steps outside. Shouting.
\n\nIt's them. There's no time. Listen - They killed innocent. They're seperated into military ranks. You've got PVT - private, the lowest one. Then, you've got Sargent or SRG, and after that, GEN or general. I've heard GEN's got highest prioirity access and info, that could finish them.
\nF/ck! They're breaking the d00r d0wn. Th3y haVe an app. W3b app. N0 t1me. I gt 2 pa22w0rd hsh from *****. Abbr from m1l1tary r4nk - PVT /s us3r..
\nHash pss: 029cc96c6d52ee0777810a4d3c55f4e6 algori0o.....o0o.....o0o.....o0o.....o0o.....o0o.....o0o.....o0o.....o0o.....o0o.....o0o.....o0o.....o0o.....o0o.....o0o.....o0o.........o......`; // Include PHP generated hashed password

    let index = 0;
    function typeText() {
        if (index < text.length) {
            terminal.textContent += text[index];
            terminal.scrollTop = terminal.scrollHeight;
            index++;
            setTimeout(typeText, 90);
        }
    }

    typeText();
</script>
<br><br>
</body>
</html>
