<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>XER.XI</title>
    <style>
        /* Add your CSS styles here */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #262626;
            color: #fff;
            text-size: 20px;
            text-align: center;
        }
        .navbar {
            background-color: #333333;
            padding: 20px 0;
            position: fixed;
            width: 100%;
            top: 0;
            z-index: 1000;
            display: flex;
            justify-content: center; /* Center the links horizontally */
            align-items: center; /* Center the links vertically */
        }

        .navbar a {
            color: #b20b0b;
            text-decoration: none;
            margin: 0 20px;
            font-size: 28px;
            position: relative; /* Add position relative */
        }

        .navbar a::before {
            content: "";
            position: absolute;
            bottom: -5px; /* Adjust as needed */
            left: 0;
            width: 0;
            height: 2px; /* Adjust line height */
            background-color: #ff0d0d; /* Line color */
            transition: width 0.3s ease; /* Transition for line width */
        }

        .navbar a:hover::before {
            width: 100%; /* Grow line to the left */
        }

        .navbar a:hover {
            color: #ff0d0d; /* Line color */
            text-decoration: none;
            margin: 0 20px;
            font-size: 22px;
            transition-duration: 0.3s;
            transform: scale(1.4);
        }

        .container {

        }
        .section {
            margin-bottom: 30px;
            overflow: hidden;
            position: relative;
        }
        .section h2 {
            color: #c00c0c; /* Gold color */

        }
        .section p {
            text-align: justify;
        }
        .image {
            width: 50%;
            float: left;
        }
        .image img {
            width: 100%;
        }
        .content {
            width: 40%;
            font-size: 22px;
            position: absolute;
            top: 50%;
            right: 5%; /* Adjust this value to fine-tune the position */
            transform: translateY(-50%);
            text-align: left;
            background: #444444;
            padding: 20px; /* Adjust padding as needed */
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.3); /* Add drop shadow */
        }


        .content h2 {
            font-size: 30px;
        }

        .map {
            width: 50%;
            float: left;
        }
        .footer {
            background-color: #333333;
            color: #fff;
            padding: 20px 0;
            position: relative;
            width: 100%;
        }
        .footer p {
            margin: 0;
        }

        .sto {
            width: 100%;
        }

        .d {
            width: 100%;
            margin: 0;
            object-fit: cover;
        }

    </style>
</head>
<body>
<div class="navbar">
    <a href="#home"><img style="width: 100px; height: auto;" src="../images/xerxi.png" alt="Another Image"></a>
    <a href="#about">About Us</a>
    <a href="#mission">Our Mission</a>
    <a href="#location">Our Location</a>
    <a href="#contact">Contact</a>
</div>
<div id="home" class="container">
    <section class="section sto">
        <div class="image d">
            <img src="../images/mainimage.png" alt="Soldiers">
        </div>
    </section>
    <section id="about" class="section">
        <div class="content">
            <h2>About Us</h2>
            <p>Welcome to XER.XI Command Center! We're a team of innovators passionate about shaping the future. With expertise in military, engineering, AI, and cybersecurity, we're dedicated to pushing the boundaries of technology.
                <br><br>Founded in 2026, our mission is simple: to redefine excellence in innovation and strategic operations. From advanced robotics to cutting-edge surveillance, we're committed to staying ahead of the curve.
                <br><br>But our vision extends beyond technology. We're also focused on making a positive impact through sustainability and community outreach.
                <br><br>Join us as we pave the way for a safer, more prosperous world. Welcome to XER.XI.</p>
        </div>
        <div class="image">
            <img style="width: 500px; height: auto;" src="../images/xerxi.png" alt="Another Image">
        </div>
    </section>
    <div class="container">
        <section id="about" class="section sto">
            <div class="image d">
                <img src="../images/another_image.jpg" alt="Soldiers">
            </div>
        </section>
    </div>
    <section id="mission" class="section">
        <div class="image">
            <img src="../images/soldier1.jpg" alt="Mission Image">
        </div>
        <div class="content">
            <h2>Our Mission</h2>
            <p>We strive for world of peace. <br>Our mission is to fight off the terrors and help civilians recover their life back to normal. <br> Our mission is to eliminate threat and give the helping hand to hurt.</p>
        </div>
    </section>
    <div class="container">
        <section id="about" class="section sto">
            <div class="image d">
                <img src="../images/another_image.jpg" alt="Soldiers">
            </div>
        </section>
    </div>
    <section id="location" class="section">
        <div class="map">
            <!-- You can embed a map here using an iframe or any other method -->
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d29325.744605671397!2d-74.00594167980425!3d40.71277626344495!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjnCsDQ4JzE2LjQiTiA3NMKwMDInMjUuNCJX!5e0!3m2!1sen!2sus!4v1629166984164!5m2!1sen!2sus" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
        </div>
        <div class="content">
            <h2>Our Location</h2>
            <p>Contact us:</p>
            <p>Email: info@xerxi.com</p>
            <p>Phone: +123456789</p>
            <p>Quick Dial: 123</p>
        </div>
    </section>
</div>
<div class="footer">
    <p>&copy; 2024 XER.XI. All rights reserved.</p>
</div>
<script>
    // Smooth scroll functionality
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            window.scrollTo({
                top: target.offsetTop - document.querySelector('.navbar').offsetHeight, // Adjusted scroll position to account for fixed navbar
                behavior: 'smooth'
            });
        });
    });

    // Highlight active link in navbar when scrolling
    window.addEventListener('scroll', () => {
        const scrollPos = window.scrollY;
        document.querySelectorAll('.navbar a[href^="#"]').forEach(link => {
            const section = document.querySelector(link.getAttribute('href'));
            if (
                section.offsetTop <= scrollPos + document.querySelector('.navbar').offsetHeight &&
                section.offsetTop + section.offsetHeight > scrollPos + document.querySelector('.navbar').offsetHeight
            ) {
                link.classList.add('active');
            } else {
                link.classList.remove('active');
            }
        });
    });
</script>

</body>
</html>
